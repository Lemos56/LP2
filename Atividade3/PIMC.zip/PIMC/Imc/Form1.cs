﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Imc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txtAltura_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCalcul_Click(object sender, EventArgs e)
        {
            double altura, peso, imc;
            if (double.TryParse(txtAltura.Text, out altura) &&
                double.TryParse(txtPesoAtual.Text, out peso))


            {
                if ((altura <= 0) || (peso <= 0))
                    MessageBox.Show("Valores devem ser maiores que 0");

                else
                {
                    imc = peso / (Math.Pow(altura, 2));


                    imc = Math.Round(imc, 1);

                    txtResult.Text = imc.ToString("N1");

                    if (imc < 18.5)
                        MessageBox.Show("Magreza", "IMC", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else if (imc <= 24.9)
                        MessageBox.Show("Normal", "IMC", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else if (imc <= 29.9)
                        MessageBox.Show("Sobrepeso (Grau de Obesidade = I)", "IMC", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else if (imc <= 39.9)
                        MessageBox.Show("Obesidade (Grau de Obesidade = II)", "IMC", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show("Obesidade Grave (Grau de Obesidade = III)", "IMC", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

            }
            else
            {
                MessageBox.Show("Valores inválidos", "Atenção!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Clear();
            txtPesoAtual.Clear();
            txtResult.Clear();

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Tem certeza que deseja sair?", "Atenção!", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation) == DialogResult.OK)

            {
                Close();
            }
            else
            {
                txtAltura.Focus();
            }
        }

        private void txtAltura_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                SendKeys.Send("{TAB}");
                e.Handled = true;
            }
        }

    }
}
