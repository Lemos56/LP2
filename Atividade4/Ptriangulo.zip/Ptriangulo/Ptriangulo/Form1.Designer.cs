﻿namespace Ptriangulo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCalcular = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.txtMed3 = new System.Windows.Forms.TextBox();
            this.txtMed2 = new System.Windows.Forms.TextBox();
            this.txtMed1 = new System.Windows.Forms.TextBox();
            this.lblMed1 = new System.Windows.Forms.Label();
            this.lblMed2 = new System.Windows.Forms.Label();
            this.lblMed3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(241, 279);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(96, 39);
            this.btnCalcular.TabIndex = 3;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(360, 279);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(88, 39);
            this.btnLimpar.TabIndex = 4;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(473, 279);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(81, 39);
            this.btnSair.TabIndex = 5;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // txtMed3
            // 
            this.txtMed3.Location = new System.Drawing.Point(338, 211);
            this.txtMed3.Name = "txtMed3";
            this.txtMed3.Size = new System.Drawing.Size(176, 20);
            this.txtMed3.TabIndex = 2;
            this.txtMed3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMed1_KeyPress);
            // 
            // txtMed2
            // 
            this.txtMed2.Location = new System.Drawing.Point(338, 167);
            this.txtMed2.Name = "txtMed2";
            this.txtMed2.Size = new System.Drawing.Size(176, 20);
            this.txtMed2.TabIndex = 1;
            this.txtMed2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMed1_KeyPress);
            // 
            // txtMed1
            // 
            this.txtMed1.Location = new System.Drawing.Point(338, 123);
            this.txtMed1.Name = "txtMed1";
            this.txtMed1.Size = new System.Drawing.Size(176, 20);
            this.txtMed1.TabIndex = 0;
            this.txtMed1.TextChanged += new System.EventHandler(this.txtMed1_TextChanged);
            this.txtMed1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMed1_KeyPress);
            // 
            // lblMed1
            // 
            this.lblMed1.AutoSize = true;
            this.lblMed1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblMed1.Location = new System.Drawing.Point(238, 126);
            this.lblMed1.Name = "lblMed1";
            this.lblMed1.Size = new System.Drawing.Size(51, 13);
            this.lblMed1.TabIndex = 6;
            this.lblMed1.Text = "Medida 1";
            // 
            // lblMed2
            // 
            this.lblMed2.AutoSize = true;
            this.lblMed2.Location = new System.Drawing.Point(238, 170);
            this.lblMed2.Name = "lblMed2";
            this.lblMed2.Size = new System.Drawing.Size(51, 13);
            this.lblMed2.TabIndex = 7;
            this.lblMed2.Text = "Medida 2";
            // 
            // lblMed3
            // 
            this.lblMed3.AutoSize = true;
            this.lblMed3.Location = new System.Drawing.Point(238, 214);
            this.lblMed3.Name = "lblMed3";
            this.lblMed3.Size = new System.Drawing.Size(51, 13);
            this.lblMed3.TabIndex = 8;
            this.lblMed3.Text = "Medida 3";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bookman Old Style", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(169, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(412, 22);
            this.label1.TabIndex = 9;
            this.label1.Text = "Calculo da Classificação dos Triângulos";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblMed3);
            this.Controls.Add(this.lblMed2);
            this.Controls.Add(this.lblMed1);
            this.Controls.Add(this.txtMed1);
            this.Controls.Add(this.txtMed2);
            this.Controls.Add(this.txtMed3);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnCalcular);
            this.MaximumSize = new System.Drawing.Size(816, 489);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.TextBox txtMed3;
        private System.Windows.Forms.TextBox txtMed2;
        private System.Windows.Forms.TextBox txtMed1;
        private System.Windows.Forms.Label lblMed1;
        private System.Windows.Forms.Label lblMed2;
        private System.Windows.Forms.Label lblMed3;
        private System.Windows.Forms.Label label1;
    }
}

