﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            
                double med1, med2, med3;
            if (txtMed1.Text.Contains("."))
            {
                txtMed1.Text = txtMed1.Text.Replace(".", ",");
            }
            if (txtMed2.Text.Contains("."))
            {
                txtMed2.Text = txtMed2.Text.Replace(".", ",");
            }
            if (txtMed3.Text.Contains("."))
            {
                txtMed3.Text = txtMed3.Text.Replace(".", ",");
            }
            if (double.TryParse(txtMed1.Text, out med1)
                    && double.TryParse(txtMed2.Text, out med2)
                    && double.TryParse(txtMed3.Text, out med3))

                {
                    if (med1 < (med2 + med3) && med1 > Math.Abs(med2 - med3) && med2 < (med1 + med3) && med2 > Math.Abs(med1 - med3)
                        && med3 < (med1 + med2) && med3 > Math.Abs(med1 - med2))
                    {
                        if (med1 == med2 && med2 == med3)
                        {
                            MessageBox.Show("O triângulo é equilátero!", "Classificação", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            if (med1 == med2 || med1 == med3 || med2 == med3)
                            {
                                MessageBox.Show("O triângulo é isóceles!", "Classificação", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                            else
                            {
                                MessageBox.Show("O triângulo é escaleno!", "Classificação", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }

                    }
                else
                {
                    MessageBox.Show("Não existe triângulo com essas medidas!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                }
            
            }
            else
            {
                MessageBox.Show("Valores inválidos.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtMed1.Clear();
            txtMed2.Clear();
            txtMed3.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Tem certeza que deseja sair?", "Atenção!", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation) == DialogResult.OK)

            {
                Close();
            }
            else
            {
                txtMed1.Focus();
            }
        }

        private void txtMed1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (Char)13)
            {
                SendKeys.Send("{TAB}");
                e.Handled = true;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtMed1_TextChanged(object sender, EventArgs e)
        {

        }
    }
    
}

